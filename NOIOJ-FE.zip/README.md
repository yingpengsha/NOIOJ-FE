# NOIOJ-FE

## Project setup
```
yarn install
yarn run serve
```

## Compiles and minifies for production
```
yarn run build
```

## Todo list

- [x] vue.config.js 配置
- [x] scss 全局样式
- [x] axios 封装
- [x] router
- [x] vuex
- [x] svg-icon 组件封装


## Other
Power by [yingpengsha](https://github.com/yingpengsha) from [Fearless Studio](https//github.com/Fearless-Studio)
