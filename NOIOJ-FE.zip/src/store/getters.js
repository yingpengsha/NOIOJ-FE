const getters = {
  isLogin: state => state.userInfo.isLogin,
  avator: state => state.userInfo.avator,
};

export default getters;
